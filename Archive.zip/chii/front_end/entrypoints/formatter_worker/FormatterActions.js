const t=["application/javascript","application/json","application/manifest+json","text/css","text/html","text/javascript","text/x-scss"];export{t as FORMATTABLE_MEDIA_TYPES};
