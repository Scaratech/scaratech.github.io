# getUserInfo() failed because no account received was a returning account.
