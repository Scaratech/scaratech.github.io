# The response body is empty when fetching the provider's client metadata.
