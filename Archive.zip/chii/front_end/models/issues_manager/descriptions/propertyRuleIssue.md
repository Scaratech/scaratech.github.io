# Ignored @property rule

An @property rule is ignored because it contains an invalid property or is missing a required one:

```
{PLACEHOLDER_property}
```
