# getUserInfo() failed because the config and well-known files were invalid.
