# getUserInfo() failed because of an invalid accounts response.
