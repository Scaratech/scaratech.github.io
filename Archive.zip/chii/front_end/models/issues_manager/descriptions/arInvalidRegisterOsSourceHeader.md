# Ensure that the `Attribution-Reporting-Register-OS-Source` header is valid

This page tried to register an OS source using the Attribution Reporting API
but failed because an `Attribution-Reporting-Register-OS-Source` response
header was invalid.
