# The provider's client metadata endpoint cannot be found.
