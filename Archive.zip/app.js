function debug(id) {
    const target = runtime.url + '/chii/target.js';

    if (!xen.wm.windows[id]) {
        window.xen.notifications.spawn({
            title: 'Debugger',
            icon: '/assets/logo.svg',
            description: `No window with ID ${id} found`,
            timeout: 2500
        });

        return;
    }

    const w = xen.wm.windows[id].el.content;

    const script = document.createElement('script');
    script.src = target;
    script.setAttribute('embedded', 'true');

    const dtf = document.createElement('iframe');
    dtf.style =
        'position: absolute; inset: 0px; width: 100%; height: 100%; border: none; margin: 0px; padding: 0px; pointer-events: auto; z-index: 2';

    document.body.appendChild(dtf);

    window.addEventListener('message', (ev) => {
        w.contentWindow.postMessage(ev.data, ev.origin);
    });

    w.contentWindow.ChiiDevtoolsIframe = dtf;
    w.contentDocument.body.appendChild(script);

    document.getElementById('window-list').innerHTML = `
        <li class="no-windows" style="color: var(--cat-green); font-style: normal;">
            Debugger attached to ID: ${id} <i class="fas fa-check-circle"></i>
        </li>
    `;
}

function render() {
    const list = document.getElementById('window-list');
    const windows = xen.wm.windows;
    const ids = Object.keys(windows);

    list.innerHTML = '';

    if (ids.length === 0) {
        list.innerHTML = `
            <li class="no-windows">No windows found</li>
        `;
        return;
    }

    ids.forEach((id) => {
        const obj = windows[id];
        const title = obj.title || `Window ${id}`;

        const item = document.createElement('li');
        item.classList.add('window-item');
        item.innerHTML = `
            <div class="window-info">
                <span class="window-title">${title}</span>
                <span class="window-id">ID: ${id}</span>
            </div>
            <button class="debug-button" onclick="debug('${id}')">
                <i class="fas fa-arrow-right-to-bracket"></i> Debug
            </button>
        `;

        list.appendChild(item);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        render();
    }, 100);
});
